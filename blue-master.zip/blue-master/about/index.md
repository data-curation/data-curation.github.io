---
layout: default
title: About blueface
---

blueface is a minimalist Jekyll theme. It is responsive, generates JSON and RSS feeds on each build, and can be easily extended. It uses your system fonts alongside Open Sans, Droid Sans and Raleway from Google Fonts. Oh, and it has support for tags too.

> It supports blockquotes, too.

## blueface on the Internet

* [blueface][github] on GitHub (Source Code)
* [nolsigan][nolsigan] nolsigan.github.io
* [rjsteckel][rjsteckel] data, beer, and stats

[github]: https://github.com/tnguyen/blueface/
[nolsigan]: http://nolsigan.github.io
[rjsteckel]: http://rjsteckel.github.io